# cplusplusFileHandling
Code to read data from and write data to external files
